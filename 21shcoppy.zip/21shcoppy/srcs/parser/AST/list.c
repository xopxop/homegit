/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   list.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthan <dthan@student.hive.fi>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/04/11 07:38:19 by dthan             #+#    #+#             */
/*   Updated: 2020/04/11 07:38:20 by dthan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/minishell.h"
#include "../../../includes/ast.h"

/*
** list : list separator_op and_or	1
**    	|                   and_or	2
*/

t_astnode	*list2(t_token **token)
{
	t_astnode *node;
	t_astnode *childnode;

	if ((childnode = and_or(token)) == NULL)
		return (NULL);
	node = build_node(AST_list);
	node->data = ft_strdup("list2");
	node->left = childnode;
	node->right = NULL;
	return (node);
}

t_astnode *list1(t_token **token)
{
	t_astnode *node;
	t_astnode *lnode;
	t_astnode *rnode;

	if ((lnode = and_or(token)) == NULL)
		return (NULL);
	if (!*token || ((ft_strcmp((*token)->data, ";") != 0) \
				&& (ft_strcmp((*token)->data, "&") != 0)))
	{	
		ft_delast(lnode);
		return (NULL);
	}
	*token = (*token)->next;
	if ((rnode = list(token)) == NULL)
	{
		ft_delast(lnode);
		return (NULL);
	}
	node = build_node(AST_list);
	node->left = lnode;
	node->right = rnode;
	node->data = ft_strdup("list1");
	return (node);
}

t_astnode *list(t_token **token)
{
	t_astnode	*node;
	t_token		*reset;

	reset = *token;
	if ((node = list1(token)) != NULL)
		return (node);
	*token = reset;
	if ((node = list2(token)) != NULL)
		return (node);
	return (NULL);
}
